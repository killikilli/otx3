function onUse(cid, item, frompos, item2, topos)
doPlayerSendTextMessage(cid,22,"This item have actionid: 999")
end